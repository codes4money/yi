package org.jivesoftware.smackx;

public interface CapsVerListener {
    public void capsVerUpdated(String capsVer);
}
